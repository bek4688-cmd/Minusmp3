from flask import Flask, render_template, request, send_file
import os
from pydub import AudioSegment

app = Flask(__name__)
UPLOAD_FOLDER = 'uploads'
OUTPUT_FOLDER = 'output'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(OUTPUT_FOLDER, exist_ok=True)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return "Fayl topilmadi", 400
    file = request.files['file']
    if file.filename == '':
        return "Fayl tanlanmadi", 400

    filepath = os.path.join(UPLOAD_FOLDER, file.filename)
    file.save(filepath)

    output_path = os.path.join(OUTPUT_FOLDER, "minus_" + file.filename)
    sound = AudioSegment.from_file(filepath)
    sound.export(output_path, format="mp3")

    text_path = os.path.join(OUTPUT_FOLDER, "lyrics.txt")
    with open(text_path, "w") as f:
        f.write("Qo‘shiq matni shu yerda paydo bo‘ladi...")

    return {
        "minus_url": "/download?file=" + output_path,
        "text_url": "/download?file=" + text_path
    }

@app.route('/download')
def download():
    file_path = request.args.get('file')
    return send_file(file_path, as_attachment=True)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=10000)
